<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Kota extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('kota_model');

    }
    public function index_get()
    {
       $id = $this->get('Id_Kota');
       if ($id === null) {

        $kota = $this->kota_model->getKota();

       } else {
        $kota = $this->kota_model->getKota($id);
        
       }
    
        if ($kota) {
            $this->response([
                'status' => true,
                'data' => $kota
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }

    }
    public function index_delete()
    {
        $id = $this->delete('Id_Kota');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'provide an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        } else {
           
            if ($this->kota_model->deleteKota($id) > 0 ) {

                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted.'
                ], REST_Controller::HTTP_NO_CONTENT);

            } else {

                $this->response([
                    'status' => false,
                    'message' => 'id not found!'
                ], REST_Controller::HTTP_BAD_REQUEST);
    
            }
        }

    }

    public function index_post()
    {
        $kota = [
            
            'Id_Kota' => $this->post('Id_Kota'),
            'Nama_Kota' => $this->post('Nama_Kota')
           
        ];

        if ($this->kota_model->createKota($kota) > 0) {
            $this->response([
                'status' =>true,
                'message' => 'new kota created.'
            ], REST_Controller::HTTP_CREATED);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to create new data!',
            ], REST_Controller::HTTP_BAD_REQUEST);
        }

    }

    public function index_put()
    {
        $id = $this->put('Id_Kota');
        $kota = [
            'Id_Kota' => $this->put('Id_Kota'),
            'Nama_Kota' => $this->put('Nama_Kota')
           
        ];
    
        if ($this->kota_model->updateKota($kota, $id) > 0) {
            $this->response([
                'status' =>true,
                'message' => 'kota updated.'
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to updated data!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}
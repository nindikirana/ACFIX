<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Pemesanan_tiket extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('pemesanan_model');

    

    }
    public function index_get()
    {
       $id = $this->get('Id_Pemesanan');
       if ($id === null) {

        $pemesanan_tiket = $this->pemesanan_model->getPemesanan_tiket();

       } else {
        $pemesanan_tiket = $this->pemesanan_model->getPemesanan_tiket($id);
        
       }
    
        if ($pemesanan_tiket) {
            $this->response([
                'status' => true,
                'data' => $pemesanan_tiket
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }

    }

    public function index_delete()
    {
        $id = $this->delete('Id_Pemesanan');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'provide an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        } else {
           
            if ($this->pemesanan_model->deletePemesanan_tiket($id) > 0 ) {

                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted.'
                ], REST_Controller::HTTP_NO_CONTENT);

            } else {

                $this->response([
                    'status' => false,
                    'message' => 'id not found!'
                ], REST_Controller::HTTP_BAD_REQUEST);
    
            }
        }

    }

    public function index_post()
    {
        $pemesanan_tiket = [
            
           'Id_Pemesanan' => $this->post('Id_Pemesanan'),
            'Id_User' => $this->post('Id_User'),
            'Qty' => $this->post('Qty'),
            'Waktu_Pemesanan' => $this->post('Waktu_Pemesanan'),
            'Id_Schedule' => $this->post('Id_Schedule'),
            'Total_Biaya' => $this->post('Total_Biaya'),
            'Status' => $this->post('Status')

        ];

        if ($this->pemesanan_model->createPemesanan_tiket($pemesanan_tiket) > 0) {
            $this->response([
                'status' =>true,
                'message' => 'new data created.'
            ], REST_Controller::HTTP_CREATED);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to create new data!',
            ], REST_Controller::HTTP_BAD_REQUEST);
        }

    }

    public function index_put()
    {
        $id = $this->put('Id_Pemesanan');
        $pemesanan_tiket = [
            'Id_Pemesanan' => $this->put('Id_Pemesanan'),
            'Id_User' => $this->put('Id_User'),
            'Qty' => $this->put('Qty'),
            'Waktu_Pemesanan' => $this->put('Waktu_Pemesanan'),
            'Id_Schedule' => $this->put('Id_Schedule'),
            'Total_Biaya' => $this->put('Total_Biaya'),
            'Status' => $this->put('Status')
           
        ];
    
        if ($this->pemesanan_model->updatePemesanan_tiket($pemesanan_tiket, $id) > 0) {
            $this->response([
                'status' =>true,
                'message' => 'data updated.'
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to updated data!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

}

<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Rental_armada extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('rental_model');

    

    }
    public function index_get()
    {
       $id = $this->get('Id_Rental');
       if ($id === null) {

        $rental_armada = $this->rental_model->getRental_armada();

       } else {
        $rental_armada = $this->rental_model->getRental_armada($id);
        
       }
    
        if ($rental_armada) {
            $this->response([
                'status' => true,
                'data' => $rental_armada
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }

    }

    public function index_delete()
    {
        $id = $this->delete('Id_Rental');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'provide an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        } else {
           
            if ($this->rental_model->deleteRental_armada($id) > 0 ) {

                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted.'
                ], REST_Controller::HTTP_NO_CONTENT);

            } else {

                $this->response([
                    'status' => false,
                    'message' => 'id not found!'
                ], REST_Controller::HTTP_BAD_REQUEST);
    
            }
        }

    }

    public function index_post()
    {
        $rental_armada = [
            
           'Id_Rental' => $this->post('Id_Rental'),
            'Id_Armada' => $this->post('Id_Armada'),
            'Id_Kota' => $this->post('Id_Kota'),
            'Id_Harga' => $this->post('Id_Harga')
            
        ];

        if ($this->rental_model->createRental_armada($rental_armada) > 0) {
            $this->response([
                'status' =>true,
                'message' => 'new data created.'
            ], REST_Controller::HTTP_CREATED);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to create new data!',
            ], REST_Controller::HTTP_BAD_REQUEST);
        }

    }

    public function index_put()
    {
        $id = $this->put('Id_Rental');
        $rental_armada = [
            'Id_Rental' => $this->put('Id_Rental'),
            'Id_Armada' => $this->put('Id_Armada'),
            'Id_Kota' => $this->put('Id_Kota'),
            'Id_Harga' => $this->put('Password')
           
        ];
    
        if ($this->rental_model->updateRental_armada($rental_armada, $id) > 0) {
            $this->response([
                'status' =>true,
                'message' => 'data updated.'
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to updated data!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

}

<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Rute_bus extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('rute_model');

    }
    public function index_get()
    {
        $id = $this->get('Id_Rute');
        if ($id === null) {

            $rute_bus = $this->rute_model->getrute_bus();
        } else {
            $rute_bus = $this->rute_model->getrute_bus($id);

        }
        if ($rute_bus) {
            $this->response([
                'status' => true,
                'data' => $rute_bus
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
}
    public function index_delete()
    {
        $id = $this->delete('Id_Rute');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'provide an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        } else {
            if ($this->rute_model->deleteRute_bus($id) > 0 ) {

                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted.'
                ], REST_Controller::HTTP_NO_CONTENT);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}

public function index_post()
{
    $rute_bus = [

        'Id_Rute' => $this->post('Id_Rute'),
        'Kota_Asal' => $this->post('Kota_Asal'),
        'Kota_Tujuan' => $this->post('Kota_Tujuan'),
        'Jam_Berangkat' => $this->post('Jam_Berangkat'),
        'Jam_Tiba' => $this->post('Jam_Tiba')
    ];

    if ($this->rute_model->createRute_bus($rute_bus) > 0) {
        $this->response([
            'status' =>true,
            'message' => 'new rute created.'
        ], REST_Controller::HTTP_CREATED);
    } else {
        $this->response([
            'status' => false,
            'message' => 'failed to create new data!',
        ], REST_Controller::HTTP_BAD_REQUEST);
}
}
public function index_put()
{
    $id = $this->put('Id_Rute');
    $rute_bus = [
        'Id_Rute' => $this->post('Id_Rute'),
        'Kota_Asal' => $this->post('Kota_Asal'),
        'Kota_Tujuan' => $this->post('Kota_Tujuan'),
        'Jam_Berangkat' => $this->post('Jam_Berangkat'),
        'Jam_Tiba' => $this->post('Jam_Tiba')
    
    ];

    if ($this->rute_model->updateRute_bus($rute_bus, $id) > 0 ) {
        $this->response([
            'status' =>true,
            'message' => 'Rute bus updated.'
        ], REST_Controller::HTTP_OK);
    } else {
        $this->response([
            'status' => false,
            'message' => 'failed to updated data!.'
        ], REST_Controller::HTTP_BAD_REQUEST);
    }
}
}
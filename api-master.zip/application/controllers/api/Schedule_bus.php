<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Schedule_bus extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('schedule_model');

    }
    public function index_get()
    {
        $id =$this->get('Id_Schedule');
        if ($id === null ){

            $schedule_bus = $this->schedule_model->getschedule_bus();
        
        } else {
            $schedule_bus = $this->schedule_model->getschedule_bus($id);
        
        }

        if ($schedule_bus) {
            $this->response([
                'status' => true,
                'data' => $schedule_bus
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }

}

public function index_delete()
{
    $id = $this->delete('Id_Schedule');

    if ($id === null) {
        $this->response([
            'status' => false,
            'message' => 'provide an id!'
        ], REST_Controller::HTTP_BAD_REQUEST);
    } else {
        if ($this->schedule_model->deleteSchedule_bus($id) > 0) {

            $this->response([
                'status' => true,
                'message' => 'deleted.'
            ], REST_Controller::HTTP_OK);

        } else {

            $this->response([
                'status' => false,
                'message' => 'id not found!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}

public function index_post()
{
    $schedule_bus = [
        'Id_Schedule' => $this->post('Id_Schedule'),
        'Id_Rute' => $this->post('Id_Rute'),
        'Id_Armada' => $this->post('Id_Armada'),
        'Id_Driver' => $this->post('Id_Driver'),
        'Id_Harga' => $this->post('Id_Harga'),
        'Tanggal_Berangkat' => $this->post('Tanggal_Berangkat'),
        'Tanggal_Sampai' => $this->post('Tanggal_Sampai')
    ];

    if ($this->schedule_model->createSchedule_bus($schedule_bus) > 0) {
        $this->response([
            'status' =>true,
            'message' => 'new schedule created.'
        ], REST_Controller::HTTP_CREATED);
    } else {
        $this->response([
            'status' => false,
            'message' => 'failed to create new data!',
        ], REST_Controller::HTTP_BAD_REQUEST);
    }
}

public function index_put()
{
    $id = $this->put('Id_Schedule');
    $schedule_bus = [
        'Id_Schedule' => $this->put('Id_Schedule'),
        'Id_Rute' => $this->put('Id_Rute'),
        'Id_Armada' => $this->put('Id_Armada'),
        'Id_Driver' => $this->put('Id_Driver'),
        'Id_Harga' => $this->put('Id_Harga'),
        'Tanggal_Berangkat' => $this->put('Tanggal_Berangkat'),
        'Tanggal_Sampai' => $this->put('Tanggal_Sampai')
    ];

    if ($this->schedule_model->updateSchedule_bus($schedule_bus, $id) > 0 ) {
        $this->response([
            'status' =>true,
            'message' => 'Schedule bus updated.'
        ], REST_Controller::HTTP_OK);
    } else {
        $this->response([
            'status' => false,
            'message' => 'failed to updated data!'
        ], REST_Controller::HTTP_BAD_REQUEST);
    }
}
}
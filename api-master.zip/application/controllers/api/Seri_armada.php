<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Seri_armada extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('seri_model');

    }
    public function index_get()
    {
        $id = $this->get('Id_Seri');
        if ($id === null) {

            $seri_armada = $this->seri_model->getSeri_armada();
        } else {
            $seri_armada = $this->seri_model->getSeri_armada($id);
        }

        if ($seri_armada) {
            $this->response([
                'status' => true,
                'data' => $seri_armada
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }

}
public function index_delete()
{
    $id = $this->delete('Id_Seri');

    if ($id === null) {
        $this->response([
            'status' => false,
            'message' => 'provide an id!'
        ], REST_Controller::HTTP_NOT_FOUND);
    } else {
        if ($this->seri_model->deleteSeri_armada($id) > 0 ) {

            $this->response([
                'status' => true,
                'id' => $id,
                'message' => 'deleted.'
            ], REST_Controller::HTTP_NO_CONTENT);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}

public function index_post()
{
    $seri_armada = [
        'Id_Seri' => $this->post('Id_Seri'),
        'Nama_Seri' => $this->post('Nama_Seri'),
        'Seat' => $this->post('Seat')
      
    ];

    if ($this->seri_model->createSeri_armada($seri_armada) > 0){
        $this->response([
            'status' =>true,
            'message' => 'new seri armada created.'
        ], REST_Controller::HTTP_CREATED);
    } else {
        $this->response([
            'status' => false,
            'message' => 'failed to create new data!'
        ], REST_Controller::HTTP_BAD_REQUEST);
    }
}

public function index_put()
{
    $id = $this->put('Id_Seri');
    $seri_armada = [
        'Id_Seri' => $this->put('Id_Seri'),
        'Nama_Seri' => $this->put('Nama_Seri'),
        'Seat' => $this->put('Seat')
    
    ];

    if ($this->seri_model->updateSeri_armada($seri_armada, $id) > 0 ) {
        $this->response([
            'status' =>true,
            'message' => 'Seri armada updated.'
        ], REST_Controller::HTTP_OK);
    } else {
        $this->response([
            'status' => false,
            'message' => 'failed to updated data!.'
        ], REST_Controller::HTTP_BAD_REQUEST);
    }
}

}
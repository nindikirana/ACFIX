<?php
use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class user extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('user_model');
    }
    public function index_get()
    {
       $id = $this->get('Id_User');
       if ($id === null) {

        $user = $this->user_model->getuser();
       } else {
        $user = $this->user_model->getuser($id);
       }
    
        if ($user) {
            $this->response([
                'status' => true,
                'data' => $user
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function index_delete()
    {
        $id = $this->delete('Id_User');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'provide an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        } else {
           
            if ($this->user_model->deleteuser($id) > 0 ) {

                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted.'
                ], REST_Controller::HTTP_NO_CONTENT);

            } else {

                $this->response([
                    'status' => false,
                    'message' => 'id not found!'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }

    public function index_post()
    {
        $user = [
            
            'Id_user' => $this->post('Id_User'),
            'Username' => $this->post('Username'),
            'Email' => $this->post('Email'),
            'Password' => $this->post('Password'),
            'No_Telp' => $this->post('No_Telp'),
            'Level' => $this->post('Level')
           
        ];

        if ($this->user_model->createuser($user) > 0) {
            $this->response([
                'status' =>true,
                'message' => 'new user created.'
            ], REST_Controller::HTTP_CREATED);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to create new data!',
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function index_put()
    {
        $id = $this->put('Id_User');
        $user = [
            'Id_user' => $this->put('Id_User'),
            'Username' => $this->put('Username'),
            'Email' => $this->put('Email'),
            'Password' => $this->put('Password'),
            'No_Telp' => $this->put('No_Telp'),
            'Level' => $this->put('Level')
           
        ];
    
        if ($this->user_model->updateuser($user, $id) > 0) {
            $this->response([
                'status' =>true,
                'message' => 'user updated.'
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to updated data!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}
